num1=int(input("Enter first number"))
num2=int(input("Enter second number"))

print(type(num1))
print(type(num2))


sum_total = print("total sum is", num1+num2)
diff_total = print("total diff is", num1-num2)


print("total multiply is ", num1*num2)
print("divide is" , num1/num2)
