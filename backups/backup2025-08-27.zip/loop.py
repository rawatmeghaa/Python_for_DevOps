# list_of_cloud =["aws" , "azure" , "gcp"]
# print(list_of_cloud)
# print(type(list_of_cloud))


# list_of_cloud.append("herouko")
# print(list_of_cloud)

# list_of_cloud.insert(3, "IBM")
# print(list_of_cloud)

# print(len(list_of_cloud))


# list_of_cloud.insert(0, "megha_cloud")
# print(list_of_cloud)



# for i in list_of_cloud:
#     print(type(i))




# for i in range(0 , 10):
#      print(i)


name= ["a", "b" , "c" , "d", "e", "f"]
print(len(name))

for i in name:
    # print(i)
    print(name.index(i))

